let a = [1,2,2]
let b = [2,2,1]

var arr1 = a.sort();
var arr2 = b.sort();

if(JSON.stringify(arr1) == JSON.stringify(arr2)){
    console.log("True")
}else{
    console.log("false")
}










































